from code_rit_algorithms.kadanes import Kadanes
from code_rit_algorithms.sort import BubbleSort,SelectionSort

arr=[1,23,0,2,3]
obj=Kadanes(arr)
obj1=SelectionSort(arr)
SelectionSort.solve(obj1)
print(arr)
