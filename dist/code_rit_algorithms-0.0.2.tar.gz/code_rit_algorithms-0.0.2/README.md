## Sorting and standard problems ##

##### This package consists of sorting algortihms in .sort python file with name of classes as Algorithms name and method 'solve' to perform the required operations. #####

### Requirements ###
"python" >= 3.0
<br>
"setuptools >= 61.0"
<br>

## Calling a sorting method ##
object=ClassName(array)
<br>
ClassName.solve(object)

## Calling a simple algorithm ##

object=ClassName(parameter)
<br>
value=ClassName.solve(object)